Nginx Config File.
==================

This is the same config file using in <http://gweb.io>.

* Replace `__PORT__` with the server port, normally `80`.
* Replace `__NAME__` with the server name, like `example.com`, `mysite.gweb.io`.
* Replace `__GOOGLE_DRIVE_ID__` with the Google Drive folder id. Make sure the folder is public.

