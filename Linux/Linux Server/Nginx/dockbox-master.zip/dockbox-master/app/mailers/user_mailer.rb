class UserMailer < ActionMailer::Base
  default from: '"Richard" <richard@dockbox.io>'

  def welcome(user_id)
    @user = User.find user_id

    mail({
      to: "\"#{@user.name}\" <#{@user.email}>",
      subject: 'Welcome to Dockbox.io'
    })

  end
end
