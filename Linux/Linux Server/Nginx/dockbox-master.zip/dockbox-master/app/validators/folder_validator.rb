class FolderValidator < ActiveModel::EachValidator
  def validate_each(record, attribute, value)
    if value.nil? || record.user != value.user || value.root?
      record.folder = nil
      record.errors[attribute] << (options[:message] || 'not valid')
    end
  end
end
