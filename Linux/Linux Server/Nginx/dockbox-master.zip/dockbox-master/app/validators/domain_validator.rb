class DomainValidator < ActiveModel::EachValidator
  def validate_each(record, attribute, value)
    return if value.blank?

    regexp = /^([a-z0-9]|\*\.)+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,6}$/

    invalid = APP_CONFIG[:domains][:invalid]

    if !(value.downcase =~ regexp)
      record.errors[attribute] << (options[:message] || "has invalid characters")
    end

    if invalid.include?(value.downcase)
      record.errors[attribute] << (options[:message] || "is reserved")
    end
  end
end
