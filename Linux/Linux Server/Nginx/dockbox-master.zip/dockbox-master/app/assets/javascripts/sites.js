$(function () {

  $('body').on('dblclick', 'fieldset.folders label', function (event) {
    if ($(this).hasClass('loading')) return false;

    var path = $(this).data('path');

    $(this).addClass('loading');
    $.get('/folders' + path);
  });

  $('body').on('click', '[data-remote]', function (event) {
    if ($(this).hasClass('loading')) return false;

    $(this).addClass('loading');
  });

  $('body').on('click', '[href*="/sync"][data-method="post"]', function (event) {
    $(this).closest('tr').addClass('syncing');
  });

});
