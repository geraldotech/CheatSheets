$(function () {
  // Disable submit button when form is submited
  $(document).on('submit', 'form', function (event) {
    $(this).find("input[type='submit']").attr('disabled', true);
  });

  // Handler for links to add a textfield
  $('body').on('click', '[data-add-field]', function (event) {

    var fieldset = $(this).closest('fieldset'),
           input = fieldset.find("input[type!='hidden']:last").clone(),
          inputs = fieldset.find('input[type="'+input.attr('type')+'"]').size(),
            name = $(this).data('add-field').replace('__INDEX__', inputs);

    input.attr('name', name);
    input.val('');

    $(this).before(input);

    return false;
  });

  $('body').on('click', 'section.header li.button', function () {
    $(this).closest('ul').toggleClass('open')
  });

});
