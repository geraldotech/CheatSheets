require 'metadata'

class Archive < ActiveRecord::Base
  belongs_to :folder

  has_one :user, through: :folder

  def relative
    path[1..-1]
  end

  def metadata
    @metadata ||= Dropbox::Metadata.new dropbox.metadata(path)
  end

  def contents
    @contents ||= dropbox.get_file(path)
  end

  def dropbox
    user.dropbox
  end

end
