class Site < ActiveRecord::Base
  scope :live, -> { where(mode: 'live') }

  belongs_to :folder
  belongs_to :user
  has_many :domains, dependent: :destroy

  # Validations
  validates :name,   presence: true, blank: false, length: (2..128)
  validates :mode,   presence: true, blank: false, inclusion: { in: %w(live freeze) }
  validates :stack,  presence: true, blank: false, inclusion: { in: %w(static) }
  validates :folder, presence: true, folder: true
  validates :domains, association_count: { minimum: 1 }

  # Callbacks
  before_save :destroy_empty_domains
  before_validation :destroy_empty_domains

  after_create  :sync, :reload_server
  after_update  :sync, :reload_server
  after_destroy :reload_server

  before_destroy :destroy_path

  accepts_nested_attributes_for :domains, :folder, allow_destroy: true

  def sync
    SyncSiteWorker.perform_async(id)
  end

  def reload_server
    ServerWorker.perform_async(:reload, id)
  end

  def directory
    I18n.transliterate(File.join(APP_CONFIG[:dropbox][:path], user.uid.to_s, id.to_s).to_s).downcase.gsub(/\s/,'-')
  end

  private

  def destroy_path
    FileUtils.rm_r directory, force: true, secure: true
  end

  def destroy_empty_domains
    domains.each { |domain| domain.mark_for_destruction if domain.name.blank? }
  end

end
