require 'nginx'
require 'metadata'

class Folder < ActiveRecord::Base
  belongs_to :user

  belongs_to :parent, class_name: Folder, foreign_key: :parent_id
    has_many :childs, class_name: Folder, foreign_key: :parent_id, dependent: :destroy

  has_many :archives, dependent: :destroy
  has_many :sites, dependent: :destroy

  def destroy_all_descendants(path)
    Folder.all_descendants(path, user_id).map(&:destroy)
  end

  def self.all_descendants(path, user_id)
    folders  = Folder.where('path = ? AND user_id = ?', path, user_id).to_a
    return [] if folders.empty?

    archvies =
      Archive.where('path = ? AND folder_id IN ?', path, folders.map(&:id)).to_a

    (folders + archives).flatten.uniq
  end

  def name
    path.split('/').last
  end

  def relative
    path[1..-1]
  end

  def uri
    'https://www.dropbox.com/home' + path
  end

  def root?
    path == '/'
  end

  def back
    (parts = path.split('/')).pop
    parts.join('/')[1..-1]
  end

  def cursor
    self[:cursor] || ''
  end

  def crawl
    contents.each do |item|
      if item.deleted?
        destroy_all_descendants(item.path)
      elsif item.dir?
        params = item.to_hash(user_id: user_id, parent_id: id)
        childs.where(path: item.path).first_or_create(params)
      end
    end
  end

  # metadata(path, file_limit=25000, list=true, hash=nil, rev=nil, include_deleted=false)
  def metadata
    @metadata ||= Dropbox::Metadata.new dropbox.metadata(path, 25000, true, nil, nil, true)
  end

  def contents
    @contents ||= metadata.contents
  end

  def delta(force = false)
    @delta = nil if force
    @delta ||= begin
      response = dropbox.delta cursor, path
      update cursor: response['cursor']
      response
    end
  end

  def dropbox
    user.dropbox
  end

end
