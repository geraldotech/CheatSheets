require 'dropbox_sdk'

class User < ActiveRecord::Base
  devise :trackable, :omniauthable, omniauth_providers: [:dropbox_oauth2]

  validate :trial_days, presence: true, numericality: { only_integer: true }

  has_many :folders
  has_many :sites,    dependent: :destroy
  has_many :payments, dependent: :destroy
  has_many :domains,  through: :folders

  after_create :create_root_folder, :welcome_email

  def self.find_for_dropbox_oauth(auth)
    user = where(uid: auth.uid.to_s, provider: auth.provider).first_or_initialize

    user.email         = user.email.present? ? user.email : auth.info.email
    user.name          = user.name.present? ? user.name : auth.info.name
    user.dropbox_token = auth.credentials.token
    user.save

    user
  end

  def sync
    sites.live.map(&:sync)
  end

  def dropbox
    @dropbox ||= DropboxClient.new(dropbox_token)
  end

  def directory
    FileUtils.mkpath(File.join(Rails.root.to_s, 'users', uid)).first
  end

  def expire_at
    if payments.any?
      payments.first.payload.date + 3.months
    else
      (created_at + trial_days.days).to_date
    end
  end

  def expired?
    Date.today >= expire_at
  end

  def expired_days
    (Date.today - expire_at).to_i
  end

  def trial_days_left
    trial = created_at + trial_days

    if expire_at >= Date.today
      (expire_at - Date.today).to_i
    end
  end

  def trial_active?
    payments.empty? && !expired?
  end

  private

  def create_root_folder
    folders.create(path: '/')
  end

  def welcome_email
    UserMailer.delay.welcome(id)
  end

end
