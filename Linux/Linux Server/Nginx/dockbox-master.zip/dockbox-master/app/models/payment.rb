require 'paypal/ipn'

class Payment < ActiveRecord::Base
  self.inheritance_column = :_type_disabled
  serialize :payload, Paypal::IPN

  default_scope { where(type: 'subscr_payment').order('created_at DESC') }

  validates :md5, presence: true, length: { is: 32 }
  validates :type, presence: true

  belongs_to :user
end
