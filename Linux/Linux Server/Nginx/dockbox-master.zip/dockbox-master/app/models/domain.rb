class Domain < ActiveRecord::Base
  default_scope { order('created_at ASC') }
  scope :wildcards, -> { where("name LIKE '*.%'") }
  scope :normal, -> { where("name NOT LIKE '*.%'") }

  belongs_to :site

  has_one :folder, through: :site
  has_one :user, through: :site

  has_many :archives, through: :folder
  has_many :childs, through: :folder
  has_one  :parent, through: :folder

  before_create :normalize_name
  before_update :normalize_name
  before_validation :normalize_name

  validates :name, uniqueness: true, domain: true, blank: false

  def wildcard?
    self.name[0] == '*'
  end

  def normalize_name
    self.name = self.name.downcase.gsub(/\.{2,}/, '.')
  end

end
