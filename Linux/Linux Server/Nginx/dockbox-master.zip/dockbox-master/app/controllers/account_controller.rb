class AccountController < ApplicationController
  before_action :authenticate_user!

  def index

  end

  def destroy
    current_user.destroy
    redirect_to root_path, notice: 'Account destroyed'
  end

end
