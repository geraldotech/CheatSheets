class DropboxWebhookController < ApplicationController
  skip_before_action :verify_authenticity_token

  def update

    if valid?
      uids = params[:delta][:users].map(&:to_s)

      User.where(uid: uids).map(&:sync)
    end

    render nothing: true
  end

  def create
    render text: params[:challenge]
  end

  private

  def sign
    key  = Rails.application.secrets.dropbox_secret
    data = request.body.read
    OpenSSL::HMAC.hexdigest(OpenSSL::Digest.new('sha256'), key, data)
  end

  def valid?
    sign == request.headers['X-Dropbox-Signature']
  end
end
