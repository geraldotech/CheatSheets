class Users::OmniauthCallbacksController < Devise::OmniauthCallbacksController

  def dropbox_oauth2
    @user = User.find_for_dropbox_oauth request.env['omniauth.auth']

    if @user.persisted?
      sign_in_and_redirect @user, event: :authentication
      set_flash_message(:notice, :success, kind: 'Dropox') if is_navigational_format?
    else
      redirect_to root_path
    end
  end
end
