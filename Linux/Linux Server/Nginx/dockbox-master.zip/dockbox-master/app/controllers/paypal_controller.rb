require 'paypal/ipn'

class PaypalController < ApplicationController
  # TODO: implement basic auth
  # http_basic_authenticate_with name: APP_CONFIG[:random][:user], password: APP_CONFIG[:random][:password], only: :ipn
  skip_before_action :verify_authenticity_token, only: :ipn
  before_action :authenticate_user!, except: :ipn

  def ipn
    @ipn = Paypal::IPN.create(params)

    render nothing: true
  end

  def success
    redirect_to account_path, notice: t('.message')
  end

  def cancel
    redirect_to account_path, notice: t('.message')
  end
end
