class PagesController < ApplicationController
  def landing
  end
end
