class SitesController < ApplicationController
  before_action :authenticate_user!
  before_action :set_site, only: [:edit, :update, :destroy, :sync]

  # GET /sites
  def index
    @sites = current_user.sites
  end

  # GET /sites/new
  def new
    @site = current_user.sites.build
    set_settings
  end

  # GET /sites/:id/edit
  def edit
    set_settings
  end

  # POST /sites
  def create
    @site = current_user.sites.create(site_params)

    if @site.save
      redirect_to sites_path, notice: t('.message')
    else
      set_settings
      render :new
    end
  end

  # PATCH|PUT /sites/:id
  def update
    if @site.update(site_params)
      redirect_to sites_path, notice: t('.message')
    else
      set_settings
      render :edit
    end
  end

  # DELETE /sites/:id
  def destroy
    @site.destroy
    redirect_to sites_url, notice: t('.message')
  end

  # GET /folders(/:path)
  def folders
    respond_to do |format|
      format.js { set_folder }
    end
  end

  # POST /sites/:id/sync
  def sync
    respond_to do |format|
      format.js { @site.sync }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_site
      @site = current_user.sites.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def site_params
      params.require(:site).permit(
        :name, :mode, :stack, :folder_id, {
          domains_attributes: [ :name, :id ]
        }).merge(stack: 'static')
    end

    def set_settings
      set_folder
      set_domain
    end

    def set_folder
      folder = @site.try(:folder) ||
               current_user.folders.where(path: path_param).first_or_create

      folder.crawl

      @site.folder = folder if @site && @site.folder.nil?

      @folder = folder.root? || request.xhr? ? folder : folder.parent
    end

    def set_domain
      @site.domains.build if @site.domains.empty?
    end

    def path_param
      "/#{params[:path]}"
    end
end
