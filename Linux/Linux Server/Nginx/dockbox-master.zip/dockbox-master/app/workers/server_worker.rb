class ServerWorker
  include Sidekiq::Worker

  def perform(action, site_id)
    @site_id = site_id
    send(action)
  end

  def reload
    server.reload
  end

  def server
    @server ||= Nginx.create(site_id)
  end

  def site_id
    @site_id
  end

end
