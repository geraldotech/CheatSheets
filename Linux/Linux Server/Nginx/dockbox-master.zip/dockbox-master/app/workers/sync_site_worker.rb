class SyncSiteWorker
  include Sidekiq::Worker

  def perform(site_id)
    @site = Site.find(site_id)
    resync(site.folder)
  end

  def sync(folder)
    @folder = folder
    ensure_folder_path
    @folder.contents.each { |item| handle(item) }
  end

  def resync(folder)
    if !Dir.exist?(generate_path(folder.relative)) ||
       site.folder(:force).delta['entries'].any?
      sync(folder)
    end

    resync(folder) if site.folder.delta['has_more']
  end

  def handle(item)
    if item.deleted?
      handle_deleted(item)
    elsif item.dir?
      handle_folder(item)
    else
      handle_archive(item)
    end
  end

  def handle_deleted(item)
    if item.dir?
      Folder.all_descendants(item.path, site.user_id).each do |child|
        destroy_folder(child.path)
        child.destroy
      end
    else
      Archive.where(path: item.path, folder: site.user.folders.pluck(:id)).each do |archive|
        destroy_archive(archive.path)
        archive.destroy
      end
    end
  end

  def handle_folder(item)
    hash_options = { parent_id: @folder.id, user_id: @folder.user_id }

    folder = @folder.childs.where(path: item.path)
      .first_or_create(item.to_hash(hash_options))

    sync(folder)
  end

  def handle_archive(item)
    @archive = @folder.archives.where(path: item.path)
      .first_or_create(item.to_hash(folder_id: @folder.id))

    CopyArchiveWorker.perform_async(@archive.id, archive_path)
  end

  def site_path
    FileUtils.mkpath(site.directory).first
  end

  def folder_path
    _path = I18n.transliterate(File.join(site_path, @folder.path)).downcase.gsub(/\s/,'-')
    FileUtils.mkpath(_path).first
  end
  alias_method :ensure_folder_path, :folder_path

  def archive_path(path = nil)
    generate_path (path || @archive.relative)
  end

  def destroy_folder(path)
    FileUtils.rm_r generate_path(path), force: true, secure: true
  end

  def destroy_archive(path)
    FileUtils.rm archive_path(path), force: true
  end

  def generate_path(path)
    File.join(site_path, path)
  end

  private

  def site
    @site
  end
end
