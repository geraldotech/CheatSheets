class CopyArchiveWorker
  include Sidekiq::Worker

  def perform(archive_id, path)
    archive = Archive.find(archive_id)
    archive.rev = archive.metadata.rev
    if archive.rev_changed? || !File.exist?(path)
      archive.save
      IO.binwrite path, archive.contents
    end
  end

end
