OmniAuth.config.full_host = lambda do |env|
  Rails.env.production? ? "https://dockbox.io" : "http://localhost:3000"
end
