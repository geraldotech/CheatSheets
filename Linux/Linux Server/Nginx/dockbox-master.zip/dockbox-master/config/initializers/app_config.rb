APP_CONFIG =
  YAML.load_file(Rails.root.join('config/config.yml'))[Rails.env].deep_symbolize_keys

unless Rails.env.production?
  FileUtils.mkpath(APP_CONFIG[:dropbox][:path]).first
  FileUtils.mkpath(APP_CONFIG[:nginx][:sites]).first
end

PAYPAL = APP_CONFIG[:paypal]
