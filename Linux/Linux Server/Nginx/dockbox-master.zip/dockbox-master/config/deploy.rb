lock '3.2.1'

set :application, 'dockbox'
set :repo_url, 'git@github.com:dockbox/dockbox.git'

set :rbenv_type, :user
set :rbenv_ruby, '2.1.3'

set :deploy_to, '/home/deploy/dockbox'

set :linked_files, %w{config/database.yml config/secrets.yml config/config.yml}
set :linked_dirs, %w{log tmp/pids tmp/cache tmp/sockets vendor/bundle public/system}

set :bundle_binstubs, nil

namespace :deploy do
  task :restart do
    on roles(:app), in: :sequence, wait: 5 do
      execute :touch, release_path.join('tmp/restart.txt')
    end
  end

  after :publishing, 'deploy:restart'
  after :finishing, 'deploy:cleanup'
end
