set :stage,     :production
set :branch,    ENV["BRANCH_NAME"] || "master"
set :rails_env, :production

set :sidekiq_role, :sidekiq

server 'dockbox-web',     user: 'deploy', roles: %w{web app db}
server 'dockbox-sidekiq', user: 'deploy', roles: %w{sidekiq}
