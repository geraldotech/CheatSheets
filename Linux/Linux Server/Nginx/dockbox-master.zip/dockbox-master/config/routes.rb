require 'sidekiq/web'

Rails.application.routes.draw do
  devise_for :users, controllers: { omniauth_callbacks: "users/omniauth_callbacks" }

  authenticate :user, lambda { |u| u.admin? } do
    mount Sidekiq::Web => '/sidekiq'
  end

  devise_scope :user do
    delete 'sign_out', to: 'devise/sessions#destroy', as: :sign_out
  end

  get  '/webhooks/dropbox', to: 'dropbox_webhook#create'
  post '/webhooks/dropbox', to: 'dropbox_webhook#update'

  resources :sites, only: [:index, :new, :create, :edit, :update, :destroy]

  post '/sites/:id/sync',   to: 'sites#sync',    as: :sync_site
  get  '/folders/(*path)', to: 'sites#folders', as: :site_folder

  get    '/account', to: 'account#index', as: :account_path
  delete '/account', to: 'account#destroy'

  get  '/paypal/cancel',  to: 'paypal#cancel',  as: :paypal_cancel
  get  '/paypal/success', to: 'paypal#success', as: :paypal_success
  post '/paypal/ipn',     to: 'paypal#ipn',     as: :paypal_ipn

  get '/', to: 'pages#landing', as: :new_session
  root to: "pages#landing"

end
