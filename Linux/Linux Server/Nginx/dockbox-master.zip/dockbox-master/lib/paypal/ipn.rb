module Paypal
  class IPN

    def initialize(payload)
      payload.map do |method, value|
        define_singleton_method(method) { value }
      end

      @payload = payload

      self
    end

    # needed for serializer
    def self.load(payload)
      new JSON.parse(payload)
    end

    # needed for serializer
    def self.dump(payload)
      payload.to_json
    end

    def self.create(payload)
      ipn = new(payload)
      ipn.save
    end

    def user
      User.find_by_id user_id
    end

    def save
      nil unless user

      user.payments.where(md5: md5).first_or_create({
        provider: 'paypal', payload: payload, md5: md5, user_id: user_id, type: txn_type
      })

      self
    end

    def user_id
      custom.to_i
    end

    def verified?
      payer_status == 'verified'
    end

    def test?
      test_ipn == '1'
    end

    def date
      if respond_to?(:subscr_date)
        subscr_date.to_datetime
      elsif respond_to?(:payment_date)
        payment_date.to_datetime
      end
    end

    def md5
      Digest::MD5.hexdigest("paypal-#{payload.to_s}")
    end

    def payload
      @payload
    end

  end
end
