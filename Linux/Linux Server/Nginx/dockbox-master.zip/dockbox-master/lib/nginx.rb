class Nginx

  def initialize(site_id)
    @site = Site.find_by_id site_id
    self
  end

  def self.create(site_id)
    Nginx.new(site_id).save
  end

  def self.template
    IO.read File.join(Rails.root, nginx[:template])
  end

  def self.nginx
    APP_CONFIG[:nginx]
  end

  def self.start
    `#{nginx[:start]}` if ok?
  end

  def self.stop
    `#{nginx[:stop]}`
  end

  def self.reload
    `#{nginx[:reload]}` if ok?
  end

  def self.test
    IO.write(nginx[:test_file],`#{nginx[:test]}`)
    File.read(nginx[:test_file]).to_s
  end

  def self.ok?
    test.blank?
  end

  def self.restart
    stop
    start
  end

  def self.port
    nginx[:port].to_s
  end

  def nginx
    Nginx.nginx
  end

  def reload
    if site.present?
      site.domains.empty? ? destroy : save
    end

    Nginx.reload
  end

  def file
    File.join(nginx[:sites], "#{site.id}.conf").to_s
  end

  def root
    _path = File.join(site.directory, site.folder.path)
    I18n.transliterate(_path).downcase.gsub(/\s/,'-')
  end

  def template
    @template ||= Nginx.template
      .gsub('__PORT__', Nginx.port)
      .gsub('__DOMAINS__', domains)
      .gsub('__ROOT__', root)
  end

  def domains
    @domains ||= site.domains.pluck(:name).join(' ')
  end

  def site
    @site
  end

  def save
    IO.write(file, template) if site.present?
    self
  end

  def destroy
    File.unlink(file) if File.exist?(file)
  end

end
