require 'date'
class Dropbox::Metadata

  def initialize(_metadata)
    @metadata = _metadata
  end

  def size
    metadata['size']
  end

  def hash
    metadata['hash']
  end

  def bytes
    metadata['bytes'].to_i
  end

  def thumb_exists
    metadata['thumb_exists'].to_s == 'true'
  end

  def rev
    metadata['rev']
  end

  def modified
    DateTime.parse metadata['modified'] rescue nil
  end

  def path
    metadata['path']
  end

  def dir?
    metadata['is_dir'].to_s == 'true'
  end

  def deleted?
    metadata['is_deleted'].to_s == 'true'
  end

  def mime_type
    metadata['mime_type']
  end

  def client_mtime
    DateTime.parse metadata['client_mtime'] rescue nil
  end

  def root
    metadata['root']
  end

  # @deprecated
  def revision
    metadata['revision']
  end

  def photo_info
    PhotoInfo.new(metadata['photo_info']) rescue nil
  end

  def contents
    @contents ||= begin
      metadata['contents'].try(:map) { |content| Dropbox::Metadata.new(content) } || []
    rescue
      []
    end
  end

  def to_hash(options = {})
    { rev: rev, path: path }.merge(options).deep_symbolize_keys
  end

  private

  def metadata
    @metadata
  end

  class PhotoInfo

    def initialize(_photo_info)
      @photo_info = _photo_info
    end

    def latitude
      photo_info['lat_long'][0].to_f
    end
    alias_method :lat, :latitude

    def longitude
      photo_info['lat_long'][1].to_f
    end
    alias_method :lng, :longitude
    alias_method :long, :longitude

    def time_taken
      DateTime.parse photo_info['time_taken']
    end

    private
    def photo_info
      @photo_info
    end

  end
end
