class CreateDomains < ActiveRecord::Migration
  def change
    create_table :domains do |t|
      t.references :site, index: true
      t.string :name
      t.string :status

      t.timestamps
    end
  end
end
