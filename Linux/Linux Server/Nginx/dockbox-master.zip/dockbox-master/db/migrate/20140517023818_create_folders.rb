class CreateFolders < ActiveRecord::Migration
  def change
    create_table :folders do |t|
      t.references :parent, index: true
      t.references :user, index: true
      t.string :rev
      t.string :status
      t.string :path
      t.string :cursor

      t.timestamps
    end
  end
end
