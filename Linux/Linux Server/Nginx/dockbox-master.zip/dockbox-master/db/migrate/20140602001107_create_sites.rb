class CreateSites < ActiveRecord::Migration
  def change
    create_table :sites do |t|
      t.string :name, nil: false
      t.string :stack, nil: false
      t.string :mode, nil: false
      t.references :user, index: true
      t.references :folder, index: true

      t.timestamps
    end
  end
end
