class AddTrialDaysToUsers < ActiveRecord::Migration
  def change
    add_column :users, :trial_days, :integer, default: 15, null: false
  end
end
