class CreateArchives < ActiveRecord::Migration
  def change
    create_table :archives do |t|
      t.string :rev
      t.string :path
      t.references :folder, index: true

      t.timestamps
    end
  end
end
