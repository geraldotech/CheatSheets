class CreatePayments < ActiveRecord::Migration
  def change
    create_table :payments do |t|
      t.string :provider
      t.text :payload
      t.string :md5, null: false
      t.string :type, null: false
      t.references :user, index: true

      t.timestamps
    end
  end
end
