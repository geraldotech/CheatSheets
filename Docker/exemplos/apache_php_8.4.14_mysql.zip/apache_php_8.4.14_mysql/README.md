- incluido configuração do Apache que já lista os arquivos
- lib SOAP
- arquivo pre configurados para
  -php.ini
  - apache.conf


By Geraldo Costa, 02, November 2025