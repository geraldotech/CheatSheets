<?php
echo 'Hello from dockercomposer ++';



phpinfo();

