<?php
echo 'Hello from dockercomposer on php-server port 8080 ++';
phpinfo();
