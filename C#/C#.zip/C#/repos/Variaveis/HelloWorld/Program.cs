﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{
    internal class Program
    {
        static void Main(string[] args){
            // Trabalhando com variaveis no C#
            // Int -  numbers inteiros
            // Float -  floating-point values => Double and Decimal
            // Bool - true or false
            // String - "text"
            // Char - 'a' => unique character
            var name = "Geraldo";
            int year = 1990;
            string favoriteColor = "blue";
            float velocidade = 305.48f;
            bool developer = true;

            Console.WriteLine("=============");
            Console.WriteLine("Name:"+name);
            Console.WriteLine("Birth:"+year);
            Console.WriteLine("Favorite Color:"+favoriteColor);
            Console.WriteLine("Speed:"+velocidade);
            Console.WriteLine("Is dev:"+ developer);
            Console.Write("text\n");
                
            // reatribuindo

            //velocidade = 50.98f;
            velocidade = velocidade + 4.67f; 
            Console.WriteLine("New speed:"+velocidade);
            Console.WriteLine(name + " nasceu em " + year);

            Console.ReadLine();

        }
    }
}
