﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{
    internal class Program
    {
        static void Main(string[] args){

            Console.WriteLine(Math.Abs(-100));
            Console.WriteLine("________functions________");
            ExibirMsg();
            ExibirMsg();

            Console.WriteLine("________functions args________");

            GerarPrecoDesconto(-75);
            // print return in console
            Console.WriteLine(Somar(1, 2, 3));
            // attr valor do return da fun a var soma2
            int soma2 = Somar(5, 5, 10);
            Console.WriteLine(soma2);

            Console.WriteLine("________Arrays________");
            // fixed length, is not dynamic / modo 1 com new
            string[] produtos = new string[5] { "Alpha", "Bravo", "Charlie", "gmapdev", "Delta"};
            Console.WriteLine(produtos[produtos.Length -1]);
            Console.WriteLine(produtos[1]);

            produtos[3] = "geradox.com";
            Console.WriteLine(produtos[3]);
            // modo 2 mais simples de declrar array

            int[] valores = {1,2,4,5};
            Console.WriteLine(valores[0]);

            Console.WriteLine("________switch________");

            string cor = "Azuxl";
            switch(cor){
                case "Vermelho":
                    Console.WriteLine("Red");
                    break;
                case "Amarelo":
                    Console.WriteLine("yellow");
                    break;
                case "Azul":
                    Console.WriteLine("Blue");
                    break;
                default: 
                    Console.WriteLine("nenhum cor definida");
                    break;
            }

            

            Console.ReadLine();
        }
        // declarando functions
        // 1 -  void  significa que nao retorna nada
        static void ExibirMsg()
        {
            Console.WriteLine("Esse sistema é show de bola");
            Console.WriteLine("Estou usando funcoes");
            Console.WriteLine("Bem vindo!");
        }
        // multi params and default value
        static void GerarPrecoDesconto(int preco, string Produto = "Produto: ?")
        {
            // Abs é um modulo: converte o valor para positivo mesmo se o user passa valores negativo
            int precoAbs = Math.Abs(preco);
            float desconto = 50 * precoAbs / 100f;
            precoAbs = precoAbs * 2;

            Console.WriteLine(Produto);
            Console.WriteLine("Preco em dobro: " + precoAbs);
            Console.WriteLine("Desconto 50%: " + desconto);
        }
        // 2 - return
        // no lugar de void adicionar o tipo de retorno int, float, string ?
        static int Somar(int a, int b, int c)
        {
            int resultadoFinal = a + b + c;
            return resultadoFinal;

            Console.WriteLine("after return code ignorado");

        }
    }
}
