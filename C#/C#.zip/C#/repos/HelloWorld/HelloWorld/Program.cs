﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{
    internal class Program
    {
            //scopo global
        static string fullName = "Geraldo P C Filho";
       
        static void Main(string[] args){
            // scopo local variaveis
            string meuNome = "Geraldo";
            Console.WriteLine(fullName);
            ExibirMsg();


            Console.ReadLine();
        }
      
        static void ExibirMsg()
        {
            string surname = "Costa";
            Console.WriteLine("Bem vindo a function!");
            Console.WriteLine(fullName);
            Console.WriteLine(surname);
        }
       
    }
}
