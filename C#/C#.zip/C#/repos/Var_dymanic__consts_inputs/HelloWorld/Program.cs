﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{
    internal class Program
    {
        static void Main(string[] args){     

            // var nao permite mudar o tipo da variable
            /*
            var corFavorita = "red";
            var notebook = "Acer, Dell";
            corFavorita = 12323;
            */
            // dynamic fora do padrao é menos performatica
            dynamic cor_favorita = "red";
            Console.WriteLine(cor_favorita);
            // dynamic permite
            cor_favorita = 2323.243f;

            Console.WriteLine(cor_favorita);


            // constants and ReadLine() get user inputs
            /*
           const float PI = 3.141592653589793f;

           string nome = "";
           Console.WriteLine("Enter your name: ");
           nome = Console.ReadLine();

           // v1 direct string nome = Console.ReadLine();
           // lembrar que tudo que é digitado pelo user no prompt é tratado como string
           Console.WriteLine("Seu nome é: ");
           Console.WriteLine(nome);
  

           Console.ReadLine();
           */
        }
    }
}
