﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{
    internal class Program
    {
        // criar tipos com Enum // enumerador - enumeraçoes
        // variavel com o tipo Cor deve ter um desses valores
        // Azul = 33 em instead 0 o valor será 33
        enum Cor { Azul, Verde, Amarelo = 55};
        static void Main(string[] args){

            Cor corFavorita = Cor.Verde;
            Cor corFavorita2 = Cor.Amarelo;
          

            // cast converter um tipo para outro
            Console.WriteLine((int)corFavorita); // valor enum 1
            Console.WriteLine(corFavorita2); // 
            Console.WriteLine((int)corFavorita2); // custom enum value  55

            Console.WriteLine((Cor)0); // Azul tipo numero para valor, lembra o index de um array

            Console.ReadLine();
        }
      
        static void ExibirMsg()
        {
            Console.WriteLine("Esse sistema é show de bola");
            Console.WriteLine("Estou usando funcoes");
            Console.WriteLine("Bem vindo!");
        }
       
    }
}
