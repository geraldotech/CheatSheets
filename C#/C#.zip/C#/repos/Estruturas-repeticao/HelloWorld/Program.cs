﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{
    internal class Program
    {
        // criar tipos com Enum // enumerador - enumeraçoes
        // variavel com o tipo Cor deve ter um desses valores
        // Azul = 33 em instead 0 o valor será 33
        enum Cor { Azul, Verde, Amarelo = 55};
        enum Opcao{ Criar = 1, Deletar, Editar, Listar, Atualizar};
        static void Main(string[] args){

            // # Estruturas de repetição #
            Console.WriteLine("==========while===========");
            // => while recebe a confica, e enquanto true se repete

            int contador = 0;
            while (contador <= 10)
            {
                Console.WriteLine(contador);
                Console.WriteLine("while");
                //contador = contador + 1;
                //contador += 1;
                  contador++;
            }

            Console.WriteLine("==========do while===========");
            // => do mesmo que a condicao seja falta vai executar apenas uma vez.

            int cont = 0;
            do
            {
                Console.WriteLine("do while", +cont);
                cont++;
            } while (cont < 10);
            Console.WriteLine("==========forEach===========");

            // => forEach - percorrer arrays

            string[] myarr = {"Geraldo", "Filho", "NodeJS", "Curso de C#", "Udemy"};     

            foreach(string item in myarr)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("==========for===========");
            //  => for
           
            for (int i = 0; i < myarr.Length; i++)
            {
                Console.WriteLine("index: " + i + myarr[i]);
            }   
            Console.WriteLine("==========ordem descrescente===========");

            for (int j =  myarr.Length - 1; j >= 0; j--)
            {
                Console.WriteLine("index: " + j + myarr[j]);

            }



            Console.WriteLine("========== switch enum ===========");
           
            Console.WriteLine("Selecione uma as opçoes abaixo: ");
            Console.WriteLine("1-Criar\n2-Deletar\n3-Editar\n4-Listar\n5-Atualizar");
            // string to ind
            int index  = int.Parse(Console.ReadLine());
            Opcao opcaoSelecionada = (Opcao)index; // mesmo que Console.WriteLine((Opcao)1);
             Console.WriteLine(opcaoSelecionada);

            switch (opcaoSelecionada)
            {
                case Opcao.Criar:
                Console.WriteLine("Quer criar alguma");
                 break;
                case Opcao.Deletar:
                    Console.WriteLine("Quer deletar");
                    break;
                case Opcao.Atualizar:
                    Console.WriteLine("Quer update now? ");
                    break;
                default:
                    Console.WriteLine("opcao nao cadastrada");
                    break;
            }          

            Console.ReadLine();
        }
      
        static void ExibirMsg()
        {
            Console.WriteLine("Esse sistema é show de bola");
            Console.WriteLine("Estou usando funcoes");
            Console.WriteLine("Bem vindo!");
        }
       
    }
}
