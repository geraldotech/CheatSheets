﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{
    internal class Program
    {
        static void Main(string[] args){
            // operadores
            /*
            float numero = 5;
            float media = numero / 2;
            int test = (2 + 2) * 10;          
            Console.WriteLine(media);
            Console.WriteLine(test);         
            */

            /*
            int a = 10;
            int b = 20;
            int c = 2;

            if (a > b) {
                Console.WriteLine("maior");
            } else if (a == c) {
                Console.Write("executou elseif");            
            } else  {
                Console.WriteLine("nenhum das condicoes");
            }
             Console.ReadLine();
            */
            // operadores logicos && (E ou AND) e || (OU / OR)
            // COND1 && CONDI2 => ambos devem retornar true
            // CONDI1 || COND2 => ambos true = true se algum for false = false
           
            int a = 10;
            int b = 20;
            int c = 2;

            if (a < b && a > c)
            {
                Console.WriteLine("maior");
            }
            else if (a == c)
            {
                Console.Write("executou elseif");
            }
            else
            {
                Console.WriteLine("nenhum das condicoes");
            }
            Console.ReadLine();
        }
    }
}
